import random, json, sys
from collections import Counter
from array import *

x = 1;
arr_rolls = []
ary =[]

norolls = int(input("please enter number of rolls to play:"))
nodice=int(input("please enter number of dice to play: "))

if norolls <= 0:
    print("you cant play game with 0 roll")
elif norolls > 1000:
    print("max roll is 1000 times")

else:
    dce = {}
    sys.stdout = open("rolls.txt","w")
    for h in range(0, norolls):
        for i in range(nodice):
            dce[i] = random.randint(1,6)
            ary.append(dce[i])
        
        total = sum(ary)
        print('roll {} : {}'.format(x, total))
        sys.stdout.close
        arr_rolls.append(total)
        x += 1