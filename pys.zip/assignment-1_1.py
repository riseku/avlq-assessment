import random, json, sys, os
from collections import Counter
from array import *
from typing import Text

norolls = 100;
x = 1;
arr_rolls = []

sys.stdout = open("rolls.json","w")
print("[")
for i in range(0, norolls):
    if x == 100:
        dc1 = random.randint(1,6)
        dc2 = random.randint(1,6)
        dc3 = random.randint(1,6)
        ary = [dc1, dc2, dc3]
        total = sum(ary)
        print("{")
        print("\"" + "roll {}\" : \"{}\"".format(x, total))
        print("}")
        arr_rolls.append(total)
    else:
        dc1 = random.randint(1,6)
        dc2 = random.randint(1,6)
        dc3 = random.randint(1,6)
        ary = [dc1, dc2, dc3]
        total = sum(ary)
        print("{")
        print("\"" + "roll {}\" : \"{}\"".format(x, total))
        print("},")
        arr_rolls.append(total)
        x += 1   
        
print("]")
sys.stdout.close

sys.stdout = open("rolls_occured.json","w")
print("[")
a_counter = 1;
while a_counter <= 18:
    if a_counter == 18:
        def countX(arr_rolls, a_counter):
            count = 0
            for occ in arr_rolls:
                if (occ == a_counter):
                    count = count + 1
            return count
        print("{")
        print("{} occurred : {} times".format(a_counter, countX(arr_rolls, a_counter)))
        print("}")
        a_counter += 1
    else:
        def countX(arr_rolls, a_counter):
            count = 0
            for occ in arr_rolls:
                if (occ == a_counter):
                    count = count + 1
            return count
        print("{")
        print("{} occurred : {} times".format(a_counter, countX(arr_rolls, a_counter)))
        print("},")
        a_counter += 1

print("]")    
sys.stdout.close